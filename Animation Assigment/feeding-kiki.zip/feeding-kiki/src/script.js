const cursor = {
  requestId: 0,
  delay: 8,
  fishContainer: document.getElementById('fish-container'),
  timeStamp: document.getElementById('timestamp'),
  // fish: document.getElementById('fish'),
  canMoveFish: false,
  fishBottom: 0,
  oldX: 0,
  oldY: 0,
  _x: 0,
  _y: 0,
  endX: (window.innerWidth / 2),
  endY: (window.innerHeight / 2),
  init: function() {
    const vh = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);
    console.log(`Viewport height: ${vh}`)
    this.viewportHeight = vh;
    // this.fishSize = this.fish.offsetWidth;
    this.setupEventListeners();
    // this.moveFish();
  },
  setupEventListeners: function() {
    let self = this;
    // const { fish, fishContainer } = self;
    const {fishContainer} = self;
    document.addEventListener('mouseenter', function() {
      console.log(`Mouse enters canvas`);
      self.start();
    })
   
    document.addEventListener('mouseleave', function(e) {
      console.log(`Leaving viewport`);
      self.stop();
    })
    document.addEventListener('mousemove', function(e) {
      console.log(`Mouse moving`);
      self.endX = e.pageX;
      self.endY = e.pageY;
      // self._x += (self.endX - self._x) / self.delay;
      // self._y += (self.endY - self._y) / self.delay;
      // console.log(`${self._x}, ${self._y}`)
    })
  },
  start: function() {
    let self = this;
     if (self.requestId === 0) {
       console.log(`This keyword in Start func: ${self}`)
       console.log(`_x: ${self._x}`)
       // bind the `this` keyword of callback function named loop to the value of `self` here.
       self.requestId = window.requestAnimationFrame(this.loop.bind(self));
     }
     
   },
  stop: function() {
    let self = this;
    console.log(`Req Id in stop: ${self.requestId}`);
    if (self.requestId !== 0) {
      window.cancelAnimationFrame(self.requestId);
      self.requestId = 0;
    }
    console.log(`EndX in self: ${self.endX}`)
    console.log(`EndX in this: ${this.endX}`)
  },
  loop: function(time) {
    let self = this;
    self.requestId = 0;
    console.log('looping');
    // console.log(`This keyword in Loop func: ${this}`)
    self.doStuff(time);
    self.start();
  },
  doStuff: function(time) {
    // console.log((time * 0.001).toFixed(2))
    let self = this;
    self._x += (self.endX - self._x) / self.delay;
    self._y += (self.endY - self._y) / self.delay;
    self.fishContainer.style.top = `${self._y}px`;
    self.fishContainer.style.left = `${self._x}px`
  },
  moveFish: function() {
    console.log(`Request Id: ${this.animationId}`);
    let self = this;
    self._x += (self.endX - self._x) / self.delay;
        self._y += (self.endY - self._y) / self.delay;
    self.fishContainer.style.top = self._y + 'px';
    self.fishContainer.style.left = self._x + 'px';
    this.animationId = requestAnimationFrame(this.moveFish.bind(self))
  }
  
 
 
}
cursor.init();