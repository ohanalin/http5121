# Feeding Kiki

A Pen created on CodePen.io. Original URL: [https://codepen.io/bytrangle/pen/jOVabjV](https://codepen.io/bytrangle/pen/jOVabjV).

Pure Javascript animation that allows users to drag Kiki the fish anywhere with the mouse cursor.